#include "in_game.h"

void set_game(int level, int chararcter, BITMAP** background, Barrier** barrier, User* user) {
    set_background(level, background);
    set_barrier(level, barrier);
    set_user_pos(level, user);
    set_user_char(chararcter, user);
}

// ��� �̹��� �ε�
void set_background(int level, BITMAP** background) {

    switch (level) {
    case 1:
        *background = load_bitmap(BACKGROUND_LV1, NULL);
        break;
    case 2:
        *background = load_bitmap(BACKGROUND_LV2, NULL);
        break;

    case 3:
        *background = load_bitmap(BACKGROUND_LV3, NULL);
        break;
    }
    if (!(*background)) {
        allegro_message("Background image loading Error");
    }
}

void set_barrier(int level, Barrier** barrier) {
    int num_barriers = 0;
    int load_barrier = 0;

    switch (level) {
    case 1:
        num_barriers = NUM_BARRIERS_LV1;
        break;

    case 2:
        num_barriers = NUM_BARRIERS_LV2;
        break;

    case 3:
        num_barriers = NUM_BARRIERS_LV3;
        break;

    default:
        allegro_message("Background image loading Error");
    }
    
    *barrier = (Barrier*)malloc(num_barriers * sizeof(Barrier));
    if (*barrier == NULL) {
        allegro_message("Memory allocation for barriers failed");
        return;
    }

    for (int i = 0; i < num_barriers; i++) {
        load_barrier = set_barrier_img(&(*barrier)[i]);

        if (load_barrier == -1) {
            allegro_message("Barrier image loading Error");
            for (int j = 0; j < i; j++) {
                destroy_bitmap((*barrier)[j].img);
            }
            free(*barrier);
            *barrier = NULL;
            return;
        }

        (*barrier)[i].x = i * OBJECT_WIDTH;
        (*barrier)[i].y = i * OBJECT_HEIGHT;
    }

}

// ĳ���� �ʱ� ��ġ ����
void set_user_pos(int level, User* user) {
    switch (level) {
    case 1:
        user->pos_x = USER_POSITION_X_LV1;
        user->pos_y = USER_POSITION_Y_LV1;
        break;
    case 2:
        user->pos_x = USER_POSITION_X_LV2;
        user->pos_y = USER_POSITION_Y_LV2;
        break;

    case 3:
        user->pos_x = USER_POSITION_X_LV3;
        user->pos_y = USER_POSITION_Y_LV3;
        break;
    }
}

// ĳ���� �̹��� �ε�
void set_user_char(int character, User* user) {
    switch (character) {
    case 1:
        user->front = load_bitmap(USER_CHARACTER_FRONT_1, NULL);
        
        user->back = load_bitmap(USER_CHARACTER_BACK_1, NULL);

        user->left1 = load_bitmap(USER_CHARACTER_LEFT1_1, NULL);
        user->left2 = load_bitmap(USER_CHARACTER_LEFT2_1, NULL);

        user->right1 = load_bitmap(USER_CHARACTER_RIGHT1_1, NULL);
        user->right2 = load_bitmap(USER_CHARACTER_RIGHT2_1, NULL);
        break;

    case 2:
        user->front = load_bitmap(USER_CHARACTER_FRONT_2, NULL);

        user->back = load_bitmap(USER_CHARACTER_BACK_2, NULL);

        user->left1 = load_bitmap(USER_CHARACTER_LEFT1_2, NULL);
        user->left2 = load_bitmap(USER_CHARACTER_LEFT2_2, NULL);

        user->right1 = load_bitmap(USER_CHARACTER_RIGHT1_2, NULL);
        user->right2 = load_bitmap(USER_CHARACTER_RIGHT2_2, NULL);
        break;

    case 3:
        user->front = load_bitmap(USER_CHARACTER_FRONT_3, NULL);

        user->back = load_bitmap(USER_CHARACTER_BACK_3, NULL);

        user->left1 = load_bitmap(USER_CHARACTER_LEFT1_3, NULL);
        user->left2 = load_bitmap(USER_CHARACTER_LEFT2_3, NULL);

        user->right1 = load_bitmap(USER_CHARACTER_RIGHT1_3, NULL);
        user->right2 = load_bitmap(USER_CHARACTER_RIGHT2_3, NULL);
        break;
    }

    if(!user->back || !user->front || !user->left1 || !user->left2 || !user->right1 || !user->right2) {
        allegro_message("User images loading Error");
    }
}

int set_barrier_img(Barrier* barrier) {

    // �̹��� �ε�
    barrier->img = load_bitmap("./img/barrier.bmp", NULL);
    
    if (!barrier->img) {
        return -1;
    }

    return 0;
}

int check_collision(int x1, int y1, int x2, int y2) {
    if (x1 + OBJECT_WIDTH > x2 && x1 < x2 + OBJECT_WIDTH && y1 + OBJECT_HEIGHT > y2 && y1 < y2 + OBJECT_HEIGHT) {
        return 1;
    }
    return 0;
}