#pragma once

#include <allegro.h>

void initializeImages();

BITMAP* water_bubble;
BITMAP * water_explode;

