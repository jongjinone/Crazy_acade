#pragma once
int New_Enter_ID(BITMAP* buffer, char* input_ID, int text_length);
int New_Enter_PWD(BITMAP* buffer, char* input_ID, char* input_PWD, int text_length);
void new_back_icon(BITMAP* buffer);
void new_ID_PWD_icon(BITMAP* buffer);
int new_check_back(BITMAP* buffer);
int main_new_register(BITMAP* buffer);
