#include "getImages.h"

BITMAP* back;
BITMAP* front;
BITMAP* left;
BITMAP* right;
BITMAP* water_bubble;
BITMAP* water_explode;

void initializeImages() {
    // �̹��� ��������

    water_bubble = load_bitmap("./img/water_bubble.bmp", NULL);
    water_explode = load_bitmap("./img/water_explode.bmp", NULL);
}