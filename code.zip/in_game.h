#pragma once

#include <allegro.h>

#define WHOLE_x 1500
#define WHOLE_y 750

#define MAX_x 1200
#define MAX_y 750

#define BACKGROUND_LV1 "./img/background1.bmp"
#define BACKGROUND_LV2 "./img/background2.bmp"
#define BACKGROUND_LV3 "./img/background3.bmp"

#define USER_CHARACTER_FRONT_1 "./img/1_front.bmp"
#define USER_CHARACTER_BACK_1 "./img/1_back.bmp"
#define USER_CHARACTER_RIGHT1_1 "./img/1_right1.bmp"
#define USER_CHARACTER_RIGHT2_1 "./img/1_right2.bmp"
#define USER_CHARACTER_LEFT1_1 "./img/1_left1.bmp"
#define USER_CHARACTER_LEFT2_1 "./img/1_left2.bmp"

#define USER_CHARACTER_FRONT_2 "./img/2_front.bmp"
#define USER_CHARACTER_BACK_2 "./img/2_back.bmp"
#define USER_CHARACTER_RIGHT1_2 "./img/2_right1.bmp"
#define USER_CHARACTER_RIGHT2_2 "./img/2_right2.bmp"
#define USER_CHARACTER_LEFT1_2 "./img/2_left1.bmp"
#define USER_CHARACTER_LEFT2_2 "./img/2_left2.bmp"

#define USER_CHARACTER_FRONT_3 "./img/3_front.bmp"
#define USER_CHARACTER_BACK_3 "./img/3_back.bmp"
#define USER_CHARACTER_RIGHT1_3 "./img/3_right1.bmp"
#define USER_CHARACTER_RIGHT2_3 "./img/3_right2.bmp"
#define USER_CHARACTER_LEFT1_3 "./img/3_left1.bmp"
#define USER_CHARACTER_LEFT2_3 "./img/3_left2.bmp"


#define USER_POSITION_X_LV1 0
#define USER_POSITION_Y_LV1 75

#define USER_POSITION_X_LV2 1
#define USER_POSITION_Y_LV2 150

#define USER_POSITION_X_LV3 2
#define USER_POSITION_Y_LV3 225

#define NUM_BARRIERS_LV1 10
#define NUM_BARRIERS_LV2 15
#define NUM_BARRIERS_LV3 20

#define OBJECT_WIDTH 100 // ��ü�� ���� ũ��
#define OBJECT_HEIGHT 75 // ��ü�� ���� ũ��

// user ����ü
typedef struct {
    BITMAP* front;
    BITMAP* back;
    BITMAP* left1;
    BITMAP* left2;

    BITMAP* right1;
    BITMAP* right2;

    int pos_x; 
    int pos_y;
    int hp;       // ĳ������ hp
    int speed;     // ĳ������ speed
    int water_bubble_cnt;     // ĳ������ ��ǳ�� ����
} User;

// barrier ����ü
typedef struct {
    BITMAP* img;
    int x;       // ��ֹ��� x��ǥ
    int y;     // ��ֹ��� y��ǥ
} Barrier;

void set_game(int level, int character, BITMAP** background, Barrier** barrier, User* user);

void set_background(int level, BITMAP** background);
void set_barrier(int level, Barrier** barrier);
void set_user_pos(int level, User* user);
void set_user_char(int character, User* user);

int set_barrier_img(Barrier* barrier);

int check_collision(int x1, int y1, int x2, int y2);
