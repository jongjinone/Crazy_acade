#pragma once

#define MAX_WIDTH 1500
#define MAX_DEPTH 750
