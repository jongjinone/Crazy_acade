#pragma once
#include <time.h>

#include "in_game.h"
#include "getImages.h"
#include "bubbles.h"

int game_start(int level, int character);
