﻿#include "in_game_main.h"

volatile int ticks = 0;

void ticker() {
    ticks++;
}

END_OF_FUNCTION(ticker)

int game_start(int level, int character)
{

    initializeImages();

    int frame_counter = 0; // 애니메이션 프레임 조정 변수
    int frame_delay = 30; // 애니메이션 프레임 간의 딜레이 설정

    int num_barriers = (level == 1) ? NUM_BARRIERS_LV1 : (level == 2) ? NUM_BARRIERS_LV2 : NUM_BARRIERS_LV3;

    BITMAP* background;
    Barrier* barrier;
    User user;

    set_game(level, character, &background, &barrier, &user);

    LOCK_FUNCTION(ticker);
    LOCK_VARIABLE(ticks);
    install_int_ex(ticker, BPS_TO_TIMER(60)); // 60 ticks per second

    // 더블 버퍼링을 위한 백 버퍼
    BITMAP* buffer = create_bitmap(MAX_x, MAX_y);

    // 캐릭터의 초기 이미지
    BITMAP* current_image = user.front;


    time_t t;
    t = time(NULL);

    initializeBubbles();

    // 게임 루프
    while (!key[KEY_ESC]) {
        while (ticks == 0) rest(1);
        while (ticks > 0) {
            int old_ticks = ticks;

            int new_user_x = user.pos_x;
            int new_user_y = user.pos_y;

            // 이동 처리
            if (key[KEY_UP]) {
                new_user_y -= 2;
                if (new_user_y < 0) new_user_y = 0; // 위쪽 경계 체크
                current_image = user.back; // 위쪽 방향키
            }
            if (key[KEY_DOWN]) {
                new_user_y += 2;
                if (new_user_y > MAX_y - OBJECT_HEIGHT) new_user_y = MAX_y - OBJECT_HEIGHT; // 아래쪽 경계 체크
                current_image = user.front; // 아래쪽 방향키
            }
            if (key[KEY_LEFT]) {
                new_user_x -= 2;
                if (new_user_x < 0) new_user_x = 0; // 왼쪽 경계 체크
                if (frame_counter % frame_delay < frame_delay / 2) {
                    current_image = user.left1;
                }
                else {
                    current_image = user.left2;
                }
                frame_counter++;
            }
            if (key[KEY_RIGHT]) {
                new_user_x += 2;
                if (new_user_x > MAX_x - OBJECT_WIDTH) new_user_x = MAX_x - OBJECT_WIDTH; // 오른쪽 경계 체크
                if (frame_counter % frame_delay < frame_delay / 2) {
                    current_image = user.right1;
                }
                else {
                    current_image = user.right2;
                }
                frame_counter++;
            }

            // 스페이스바를 눌렀을 때 위치와 생성 시간 기록
            if (key[KEY_SPACE]) {
                setBubble(user.pos_x, user.pos_y);
            }
            draw_sprite(buffer, background, 0, 0);

            user.pos_x = new_user_x;
            user.pos_y = new_user_y;

            // 물풍선 터트리기 (buffer, size 넘겨줘야함)
            explodeBubbles(buffer, 3, background);

            // 충돌 감지
            //int collision = 0;
            //for (int i = 0; i < num_barriers; i++) {
            //    if (check_collision(new_user_x, new_user_y, barrier[i].x, barrier[i].y)) {
            //        collision = 1;
            //        break;
            //    }
            //}

            // 충돌이 없으면 위치 업데이트
            //if (!collision) {
                
            //}

            // 백 버퍼를 지우고 다시 그리기
            //clear_to_color(buffer, makecol(0, 0, 0)); // 백 버퍼를 검은색으로 지움
            //draw_sprite(buffer, background, 0, 0);

            // 격자 그리기
            for (int i = 0; i <= MAX_x; i += 100) {
                line(buffer, i, 0, i, 750, makecol(255, 255, 255)); // 세로선
            }
            for (int i = 0; i <= MAX_y; i += 75) {
                line(buffer, 0, i, 1200, i, makecol(255, 255, 255)); // 가로선
            }

            draw_sprite(buffer, current_image, user.pos_x, user.pos_y); // 백 버퍼에 캐릭터 이미지 그리기


            // 장애물 그리기
            for (int i = 0; i < num_barriers; i++) {
                draw_sprite(buffer, barrier[i].img, barrier[i].x, barrier[i].y);
            }

            // 백 버퍼의 내용을 화면에 그리기
            blit(buffer, screen, 0, 0, 0, 0, MAX_x, MAX_y);

            ticks--;
            if (ticks != old_ticks) break;
        }
    }

    destroy_bitmap(buffer);
    destroy_bitmap(user.back);
    destroy_bitmap(user.front);
    destroy_bitmap(user.left1);
    destroy_bitmap(user.left2);
    destroy_bitmap(user.right1);
    destroy_bitmap(user.right2);
    destroy_bitmap(background);
    destroy_bitmap(water_bubble);
    destroy_bitmap(water_explode);


    // 장애물 이미지 해제
    for (int i = 0; i < num_barriers; i++) {
        destroy_bitmap(barrier[i].img);
    }
    free(barrier);

    return 0;
}
